// src/pages/auth/sign-out.tsx
import { GetServerSidePropsContext } from "next";
import { createPagesServerClient } from "@supabase/auth-helpers-nextjs";

export default function SignOut() {
  // This page never renders; we redirect in getServerSideProps.
  return null;
}

export async function getServerSideProps(ctx: GetServerSidePropsContext) {
  const supabase = createPagesServerClient(ctx);

  // Clear the auth cookies on the server
  await supabase.auth.signOut();

  // Optionally also nuke any client state by setting a short-lived "signed_out" cookie (not required)
  // ctx.res.setHeader("Set-Cookie", "signed_out=1; Path=/; Max-Age=5; SameSite=Lax");

  return {
    redirect: {
      destination: "/auth/sign-in",
      permanent: false,
    },
  };
}
