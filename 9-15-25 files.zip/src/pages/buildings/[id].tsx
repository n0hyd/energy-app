// src/pages/buildings/[id].tsx
import { GetServerSidePropsContext } from "next";
import Link from "next/link";
import { createServerSupabaseClient } from "@supabase/auth-helpers-nextjs";

type BillRow = {
  id: string;
  period_start: string;
  period_end: string;
  total_cost: number | null;
  demand_cost: number | null; // if you’ve added this column
};

type ReadingRow = {
  bill_id: string;
  usage_kwh: number;
};

type Props = {
  buildingId: string;
  buildingName: string;
  bills: Array<
    BillRow & {
      usage_kwh?: number; // merged in from usage_readings
    }
  >;
  kpis: {
    lastCost?: number;
    lastUsage?: number;
    lastDollarsPerKwh?: number;
    lastDemandPct?: number;
  };
};

export default function BuildingDetail({ buildingId, buildingName, bills, kpis }: Props) {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">{buildingName}</h1>
        <div className="space-x-2">
          <Link href={`/bills/manual-entry?building=${buildingId}`} className="btn btn-primary">
            Add Bill
          </Link>
          <Link href="/buildings" className="btn">Back</Link>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="card p-4">
          <div className="text-sm text-gray-500">Last Bill – Total Cost</div>
          <div className="text-2xl font-bold">{kpis.lastCost != null ? `$${kpis.lastCost.toFixed(2)}` : "—"}</div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-gray-500">Last Bill – Usage</div>
          <div className="text-2xl font-bold">
            {kpis.lastUsage != null ? `${Math.round(kpis.lastUsage).toLocaleString()} kWh` : "—"}
          </div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-gray-500">Last Bill – $/kWh</div>
          <div className="text-2xl font-bold">
            {kpis.lastDollarsPerKwh != null ? `$${kpis.lastDollarsPerKwh.toFixed(4)}` : "—"}
          </div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-gray-500">Last Bill – Demand %</div>
          <div className="text-2xl font-bold">
            {kpis.lastDemandPct != null ? `${(kpis.lastDemandPct * 100).toFixed(1)}%` : "—"}
          </div>
        </div>
      </div>

      {/* Recent Bills */}
      <div className="card p-4">
        <h2 className="text-lg font-semibold mb-3">Recent Bills</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left border-b">
                <th className="py-2 pr-4">Billing Period</th>
                <th className="py-2 pr-4">Usage (kWh)</th>
                <th className="py-2 pr-4">Total Cost ($)</th>
                <th className="py-2 pr-4">Demand Cost ($)</th>
                <th className="py-2 pr-4">$ / kWh</th>
              </tr>
            </thead>
            <tbody>
              {bills.map((b) => {
                const unit = b.usage_kwh && b.usage_kwh > 0 && b.total_cost != null
                  ? b.total_cost / b.usage_kwh
                  : undefined;
                return (
                  <tr key={b.id} className="border-b last:border-0">
                    <td className="py-2 pr-4">
                      {new Date(b.period_start).toLocaleDateString()} – {new Date(b.period_end).toLocaleDateString()}
                    </td>
                    <td className="py-2 pr-4">{b.usage_kwh != null ? Math.round(b.usage_kwh).toLocaleString() : "—"}</td>
                    <td className="py-2 pr-4">{b.total_cost != null ? b.total_cost.toFixed(2) : "—"}</td>
                    <td className="py-2 pr-4">{b.demand_cost != null ? b.demand_cost.toFixed(2) : "—"}</td>
                    <td className="py-2 pr-4">{unit != null ? unit.toFixed(4) : "—"}</td>
                  </tr>
                );
              })}
              {bills.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-4 text-gray-500">No bills yet. Add your first bill.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export async function getServerSideProps(ctx: GetServerSidePropsContext) {
  const supabase = createServerSupabaseClient(ctx);

  const {
    data: { session },
  } = await supabase.auth.getSession();

  if (!session) {
    return {
      redirect: { destination: `/sign-in?redirect=${encodeURIComponent(ctx.resolvedUrl)}`, permanent: false },
    };
  }

  const buildingId = ctx.params?.id as string;

  // Building (RLS ensures membership)
  const { data: building, error: bErr } = await supabase
    .from("buildings")
    .select("id,name")
    .eq("id", buildingId)
    .single();

  if (bErr || !building) {
    return { notFound: true };
  }

  // Recent bills (12)
  const { data: billsRaw, error: billsErr } = await supabase
    .from("bills")
    .select("id,period_start,period_end,total_cost,demand_cost")
    .eq("building_id", buildingId)
    .order("period_end", { ascending: false })
    .limit(12);

  if (billsErr) {
    return { props: { buildingId: building.id, buildingName: building.name, bills: [], kpis: {} } };
  }

  // Fetch usage readings for these bills and merge
  const billIds = (billsRaw ?? []).map((b) => b.id);
  let usageByBill = new Map<string, number>();

  if (billIds.length > 0) {
    const { data: readings } = await supabase
      .from("usage_readings")
      .select("bill_id,usage_kwh")
      .in("bill_id", billIds);

    (readings ?? []).forEach((r: ReadingRow) => {
      usageByBill.set(r.bill_id, Number(r.usage_kwh));
    });
  }

  const bills = (billsRaw ?? []).map((b) => ({
    ...b,
    usage_kwh: usageByBill.get(b.id),
  }));

  // KPIs from the most recent bill
  const last = bills[0];
  const kpis = {
    lastCost: last?.total_cost ?? undefined,
    lastUsage: last?.usage_kwh ?? undefined,
    lastDollarsPerKwh:
      last?.total_cost != null && last?.usage_kwh && last.usage_kwh > 0
        ? last.total_cost / last.usage_kwh
        : undefined,
    lastDemandPct:
      last?.total_cost && last.total_cost > 0 && last?.demand_cost != null
        ? last.demand_cost / last.total_cost
        : undefined,
  };

  return {
    props: {
      buildingId: building.id,
      buildingName: building.name,
      bills,
      kpis,
      initialSession: session, // so _app can hydrate
    },
  };
}
