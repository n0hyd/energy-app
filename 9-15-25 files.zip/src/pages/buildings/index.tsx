// src/pages/buildings/index.tsx
import { GetServerSidePropsContext } from "next";
import Link from "next/link";
import { createPagesServerClient } from "@supabase/auth-helpers-nextjs";

type Building = { id: string; name: string; created_at: string };
type Props = { buildings: Building[] };

export default function BuildingsPage({ buildings }: Props) {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Buildings</h1>
        <Link href="/buildings/new" className="btn btn-primary">New Building</Link>
      </div>

      <div className="card p-4">
        <table className="min-w-full text-sm">
          <thead>
            <tr className="text-left border-b">
              <th className="px-4 py-2">Name</th>
              <th className="px-4 py-2">Created</th>
              <th className="px-4 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {buildings.map((b) => (
              <tr key={b.id} className="border-b last:border-0">
                <td className="px-4 py-3">{b.name}</td>
                <td className="px-4 py-3">{new Date(b.created_at).toLocaleDateString()}</td>
                <td className="px-4 py-3">
                  <Link href={`/buildings/${b.id}`} className="btn btn-sm">View</Link>
                </td>
              </tr>
            ))}
            {buildings.length === 0 && (
              <tr>
                <td colSpan={3} className="px-4 py-6 text-gray-500">No buildings yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export async function getServerSideProps(ctx: GetServerSidePropsContext) {
  const supabase = createPagesServerClient(ctx);
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) {
    return { redirect: { destination: "/auth/sign-in?redirect=/buildings", permanent: false } };
  }

  const { data: buildings, error } = await supabase
    .from("buildings")
    .select("id,name,created_at")
    .order("created_at", { ascending: false });

  if (error) console.error("Error loading buildings:", error.message);

  return {
    props: { buildings: buildings ?? [], initialSession: session },
  };
}
